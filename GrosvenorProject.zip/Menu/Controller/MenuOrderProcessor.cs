﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using Suresh.Common;
using Suresh.Entity;
using Suresh.Repository;

namespace Suresh.Controller
{
    public class MenuOrderProcessor: IMenuOrderProcessor
    {
        ArrayList sortedDishList;
        SessionType processingSessionType;
        int processingID = 0;
        private const int MORNING_COFFEE_VALUE = 3;
        private const int NIGHT_POTATO_VALUE = 2;

        public MenuOrderProcessor(ArrayList dishList, SessionType enteredSessionType)
        {
            this.sortedDishList = dishList;
            this.processingSessionType = enteredSessionType;
        }


        public List<ViewModalDish> ProcessWorkOrder()
        {
            List<ViewModalDish> viewModalDishes = new List<ViewModalDish>();

            for (int dishIndex = 0; dishIndex < sortedDishList.Count; ++dishIndex)
            {
                if (processingID != Convert.ToInt32(sortedDishList[dishIndex]))
                {

                    MenuProcessingSvc svc = new MenuProcessingSvc();
                    var selectedDish = svc.GetDishes(this.processingSessionType).FirstOrDefault(dis => dis.ID == Convert.ToInt32(sortedDishList[dishIndex]));
                    string dishName = string.Empty;
                    if (selectedDish != null)
                    {
                        dishName = selectedDish.DishName;
                    }

                    viewModalDishes.Add(new ViewModalDish
                    {
                        ID = Convert.ToInt32(sortedDishList[dishIndex]),
                        Count = 1,
                        Dish = dishName,
                        hasError = dishName == string.Empty ? true : false  //If dish not found, update error flag
                    });
                }
                else
                {
                    var item = viewModalDishes.FirstOrDefault(vm => vm.ID == processingID);
                    item.Count = item.Count + 1;
                }

                processingID = Convert.ToInt32(sortedDishList[dishIndex]);

                //Validate Morning - Can order multiple coffee(3)
                if (this.processingSessionType == SessionType.MORNING)
                {
                    if (processingID != MORNING_COFFEE_VALUE)
                    {
                        //Not the last item
                        if (dishIndex <= sortedDishList.Count - 1)
                        {
                            //Not a last item
                            if (dishIndex != sortedDishList.Count - 1)
                            {
                                if (Convert.ToInt32(sortedDishList[dishIndex + 1]) == processingID)
                                {
                                    var item = viewModalDishes.FirstOrDefault(vm => vm.ID == processingID);
                                    item.hasError = true;
                                }
                            }
                        }
                    }
                }


                //at Night can order multiple potatos(2)
                if (this.processingSessionType == SessionType.NIGHT)
                {
                    if (processingID != NIGHT_POTATO_VALUE)
                    {
                        //Not the last item
                        if (dishIndex <= sortedDishList.Count - 1)
                        {
                            //Not a last item
                            if (dishIndex != sortedDishList.Count - 1)
                            {
                                if (Convert.ToInt32(sortedDishList[dishIndex + 1]) == processingID)
                                {
                                    var item = viewModalDishes.FirstOrDefault(vm => vm.ID == processingID);
                                    item.hasError = true;
                                }
                            }
                        }
                    }
                }
            }

            return viewModalDishes;
        }

    }
}
