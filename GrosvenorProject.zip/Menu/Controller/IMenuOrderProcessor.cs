﻿using System.Collections.Generic;
using Suresh.Entity;

namespace Suresh.Controller
{
    public interface IMenuOrderProcessor
    {
        List<ViewModalDish> ProcessWorkOrder();
    }
}
