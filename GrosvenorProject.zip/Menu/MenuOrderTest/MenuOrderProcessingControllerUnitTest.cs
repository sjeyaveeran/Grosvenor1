﻿using System.Collections;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Suresh.Common;
using Suresh.Controller;
using Suresh.Entity;

namespace MenuOrderTest
{
    [TestClass]
    public class MenuOrderProcessingControllerUnitTest
    {
        [TestMethod]
        public void ProcessWorkOrderInvalid()
        {
            ArrayList sortedDishList = new ArrayList();
            string orders = "invalid,1,2,3";
            string[] sOrderArray = orders.Split(',');

            SessionType enteredSessionType = SessionType.INVALID;

            MenuOrderProcessor processor = new MenuOrderProcessor(sortedDishList, enteredSessionType);
            List<ViewModalDish> viewModalDishes = processor.ProcessWorkOrder();

            Assert.AreEqual(0, 0);

        }

        [TestMethod]
        public void ProcessWorkOrderMorning()
        {
            //ArrayList sortedDishList = new ArrayList();
            string orders = "morning,1,2,3";
            string[] sOrderArray = orders.Split(',');

                ArrayList sortedDishList  = new ArrayList();
                for (int orderArrayIndex = 1; orderArrayIndex < sOrderArray.Length; ++orderArrayIndex)
                {
                    int outOrderArray;
                    if (int.TryParse(sOrderArray[orderArrayIndex], out outOrderArray))
                    {
                        sortedDishList.Add(outOrderArray);
                    }
                }

            SessionType enteredSessionType = SessionType.MORNING;
            MenuOrderProcessor processor = new MenuOrderProcessor(sortedDishList, enteredSessionType);
            List<ViewModalDish> viewModalDishes = processor.ProcessWorkOrder();

            //Egg count (1)            
            Assert.AreEqual(1, viewModalDishes[1].Count);

        }


        [TestMethod]
        public void ProcessWorkOrderNight()
        {
            //ArrayList sortedDishList = new ArrayList();
            string orders = "night,1,2,3";
            string[] sOrderArray = orders.Split(',');

            ArrayList sortedDishList = new ArrayList();
            for (int orderArrayIndex = 1; orderArrayIndex < sOrderArray.Length; ++orderArrayIndex)
            {
                int outOrderArray;
                if (int.TryParse(sOrderArray[orderArrayIndex], out outOrderArray))
                {
                    sortedDishList.Add(outOrderArray);
                }
            }

            SessionType enteredSessionType = SessionType.NIGHT;
            MenuOrderProcessor processor = new MenuOrderProcessor(sortedDishList, enteredSessionType);
            List<ViewModalDish> viewModalDishes = processor.ProcessWorkOrder();

            //Steak count (1)            
            Assert.AreEqual(1, viewModalDishes[1].Count);

        }


        [TestMethod]
        public void ProcessWorkOrderMorningNgativeTest()
        {
            //ArrayList sortedDishList = new ArrayList();
            string orders = "MORNING,1,1,1";
            string[] sOrderArray = orders.Split(',');

            ArrayList sortedDishList = new ArrayList();
            for (int orderArrayIndex = 1; orderArrayIndex < sOrderArray.Length; ++orderArrayIndex)
            {
                int outOrderArray;
                if (int.TryParse(sOrderArray[orderArrayIndex], out outOrderArray))
                {
                    sortedDishList.Add(outOrderArray);
                }
            }

            SessionType enteredSessionType = SessionType.MORNING;
            MenuOrderProcessor processor = new MenuOrderProcessor(sortedDishList, enteredSessionType);
            List<ViewModalDish> viewModalDishes = processor.ProcessWorkOrder();

            //Steak count (1)            
            Assert.AreEqual(true, viewModalDishes[0].hasError);

        }


        [TestMethod]
        public void ProcessWorkOrderMorningCanOrderMultipleCoffeeTest()
        {
            //ArrayList sortedDishList = new ArrayList();
            string orders = "MORNING,1,2,3,3,3";
            string[] sOrderArray = orders.Split(',');

            ArrayList sortedDishList = new ArrayList();
            for (int orderArrayIndex = 1; orderArrayIndex < sOrderArray.Length; ++orderArrayIndex)
            {
                int outOrderArray;
                if (int.TryParse(sOrderArray[orderArrayIndex], out outOrderArray))
                {
                    sortedDishList.Add(outOrderArray);
                }
            }

            SessionType enteredSessionType = SessionType.MORNING;
            MenuOrderProcessor processor = new MenuOrderProcessor(sortedDishList, enteredSessionType);
            List<ViewModalDish> viewModalDishes = processor.ProcessWorkOrder();

            //Steak count (1)            
            Assert.AreEqual(3, viewModalDishes[2].Count);

        }

        [TestMethod]
        public void ProcessWorkOrderNightCanOrderMultiplePotatoTest()
        {
            //ArrayList sortedDishList = new ArrayList();
            string orders = "night,1,2,2,3,4";
            string[] sOrderArray = orders.Split(',');

            ArrayList sortedDishList = new ArrayList();
            for (int orderArrayIndex = 1; orderArrayIndex < sOrderArray.Length; ++orderArrayIndex)
            {
                int outOrderArray;
                if (int.TryParse(sOrderArray[orderArrayIndex], out outOrderArray))
                {
                    sortedDishList.Add(outOrderArray);
                }
            }

            SessionType enteredSessionType = SessionType.NIGHT;
            MenuOrderProcessor processor = new MenuOrderProcessor(sortedDishList, enteredSessionType);
            List<ViewModalDish> viewModalDishes = processor.ProcessWorkOrder();

            //Steak count (1)            
            Assert.AreEqual(2, viewModalDishes[1].Count);

        }

        [TestMethod]
        public void ProcessWorkOrderNightNgativeTest()
        {
            //ArrayList sortedDishList = new ArrayList();
            string orders = "night,1,1,1";
            string[] sOrderArray = orders.Split(',');

            ArrayList sortedDishList = new ArrayList();
            for (int orderArrayIndex = 1; orderArrayIndex < sOrderArray.Length; ++orderArrayIndex)
            {
                int outOrderArray;
                if (int.TryParse(sOrderArray[orderArrayIndex], out outOrderArray))
                {
                    sortedDishList.Add(outOrderArray);
                }
            }

            SessionType enteredSessionType = SessionType.NIGHT;
            MenuOrderProcessor processor = new MenuOrderProcessor(sortedDishList, enteredSessionType);
            List<ViewModalDish> viewModalDishes = processor.ProcessWorkOrder();

            //Steak count (1)            
            Assert.AreEqual(true, viewModalDishes[0].hasError);

        }

    }
}
