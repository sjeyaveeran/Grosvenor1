﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using Suresh.Entity;
using Suresh.Common;
using Suresh.Repository;

namespace MenuOrderTest
{
    [TestClass]
    public class MenuOrderRepositoryUnitTest
    {

        [TestMethod]
        public void GetMorningDishes()
        {
            MenuProcessingSvc svc = new MenuProcessingSvc();
            List<Dish> dishes = svc.GetDishes(SessionType.MORNING);

            Assert.IsTrue(dishes != null && dishes.Count > 0);
        }


        [TestMethod]
        public void GetNightDishes()
        {
            MenuProcessingSvc svc = new MenuProcessingSvc();
            List<Dish> dishes = svc.GetDishes(SessionType.NIGHT);

            Assert.IsTrue(dishes != null && dishes.Count > 0);
        }


        [TestMethod]
        public void GetInvalidDishes()
        {
            MenuProcessingSvc svc = new MenuProcessingSvc();
            List<Dish> dishes = svc.GetDishes(SessionType.INVALID);

            Assert.IsTrue(dishes != null && dishes.Count == 0);
        }







    }
}
