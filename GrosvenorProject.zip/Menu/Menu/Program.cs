﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Suresh.Common;
using Suresh.Controller;
using Suresh.Entity;
using Suresh.Repository;

namespace Menu
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please enter your order. Ex: Night,1,2,2,3");
            string orders = Console.ReadLine();
            SessionType enteredSessionType = SessionType.INVALID;

            string[] sOrderArray = orders.Split(',');
            
            if (sOrderArray.Length > 0 )
            {
                //Check the first argument is valid
                switch (sOrderArray[0].ToUpper().Trim())
                {
                    case "MORNING":
                        enteredSessionType = SessionType.MORNING;
                        break;
                    case "NIGHT":
                        enteredSessionType = SessionType.NIGHT;
                        break;
                    default:
                        break;
                }

                if (enteredSessionType == SessionType.INVALID)
                {
                    Console.WriteLine("Error processing input. (Input should startswith morning (or) night");
                    goto Error;
                }


                List<ViewModalDish> viewModalDishes = new List<ViewModalDish>(); 
                ArrayList sortedDishList  = new ArrayList();
                if (sOrderArray.Length > 1)
                {
                    for (int orderArrayIndex = 1; orderArrayIndex < sOrderArray.Length; ++orderArrayIndex)
                    {
                        int outOrderArray;
                        if (int.TryParse(sOrderArray[orderArrayIndex], out outOrderArray))
                        {
                            sortedDishList.Add(outOrderArray);
                        }
                    }
                    //sort input array.
                    sortedDishList.Sort();
                    MenuOrderProcessor processor = new MenuOrderProcessor(sortedDishList, enteredSessionType);
                    viewModalDishes  = processor.ProcessWorkOrder();
                    Console.WriteLine(viewString(viewModalDishes).TrimEnd(','));
                }

                else //split.Length > 1
                {
                    Console.WriteLine("Error processing input - atleast one selection required....ex: monring,1");
                    goto Error;
                }
            }            
            else
            {
                Console.WriteLine ("Error processing input...");
                goto Error;
            }
            Error:
                Console.ReadLine();
        }

        public static string viewString(List<ViewModalDish> viewModalDishes)
        {
            StringBuilder sbPrintOutput = new StringBuilder();
            foreach (ViewModalDish vmDish in viewModalDishes)
            {
                if (!vmDish.hasError)
                {

                    if (vmDish.Count > 1)
                    {
                        sbPrintOutput.Append(string.Format("{0}(x{1}),", vmDish.Dish, vmDish.Count.ToString()));
                    }
                    else
                    {
                        sbPrintOutput.Append(string.Format("{0},", vmDish.Dish));
                    }
                }
                else //Has error in the input
                {
                    sbPrintOutput.Append("Error");
                    break;
                    //Console.WriteLine(sbPrintOutput.ToString());
                    //goto Error;
                }
            }
            return sbPrintOutput.ToString();
        }
    }
}