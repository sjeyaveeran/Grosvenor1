﻿using System.Collections.Generic;
using Suresh.Common;
using Suresh.Entity;

namespace Suresh.Repository
{
    public class MenuProcessingSvc : IMenuProcessingSvc
    {
        public List<Dish> GetDishes(SessionType session)
        {
            List<Dish> dishes = new List<Dish>();
            if (session == SessionType.MORNING)
            {
                dishes.Add(new Dish { ID = 1, Session = SessionType.MORNING, DishName = "Egg", Type = DishType.Entree });
                dishes.Add(new Dish { ID = 2, Session = SessionType.MORNING, DishName = "Toast", Type = DishType.Side });
                dishes.Add(new Dish { ID = 3, Session = SessionType.MORNING, DishName = "Coffee", Type = DishType.Drink });
            }
            else if (session == SessionType.NIGHT)
            {
                dishes.Add(new Dish { ID = 1, Session = SessionType.NIGHT, DishName = "Steak", Type = DishType.Entree });
                dishes.Add(new Dish { ID = 2, Session = SessionType.NIGHT, DishName = "Potato", Type = DishType.Side });
                dishes.Add(new Dish { ID = 3, Session = SessionType.NIGHT, DishName = "Wine", Type = DishType.Drink });
                dishes.Add(new Dish { ID = 4, Session = SessionType.NIGHT, DishName = "Cake", Type = DishType.Dessert });
            }
            return dishes;
        }
    }
}
