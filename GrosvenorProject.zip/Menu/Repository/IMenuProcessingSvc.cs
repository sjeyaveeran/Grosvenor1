﻿using System.Collections.Generic;
using Suresh.Common;
using Suresh.Entity;

namespace Suresh.Repository
{
    public interface IMenuProcessingSvc
    {
        List<Dish> GetDishes(SessionType session);
    }
}
