﻿using System;
using Suresh.Common;

namespace Suresh.Entity
{
    [Serializable]
    public class Dish
    {
        public Int32 ID { get; set; }
        public SessionType Session { get; set; }
        public string DishName { get; set; }
        public DishType Type { get; set; }
    }
}
