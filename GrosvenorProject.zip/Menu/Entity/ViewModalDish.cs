﻿using System;

namespace Suresh.Entity
{
    [Serializable]
    public class ViewModalDish
    {
        public Int32 ID { get; set; }
        public Int32 Count { get; set; }
        public string Dish { get; set; }
        public bool hasError { get; set; }
    }
}
