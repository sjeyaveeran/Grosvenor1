﻿
namespace Suresh.Common
{
    public enum SessionType : int
    {
        INVALID = 0,
        MORNING = 1,
        NIGHT = 2
    }

    public enum DishType : int
    {
        Entree = 1,
        Side = 2,
        Drink = 3,
        Dessert = 4
    }
}
